declare module 'react-login-page/logo-rect' {
  import { FC } from 'react';
  const Logo: FC<React.SVGProps<SVGSVGElement>>;
  export default Logo;
}
