declare module 'react-login-page/logo' {
  import { FC } from 'react';
  const Logo: FC<React.SVGProps<SVGSVGElement>>;
  export default Logo;
}
