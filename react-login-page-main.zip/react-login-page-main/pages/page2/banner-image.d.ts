declare module '@react-login-page/page2/banner-image' {
  const bannerImage: string;
  export default bannerImage;
}
