declare module '@react-login-page/page3/banner-image' {
  const bannerImage: string;
  export default bannerImage;
}
